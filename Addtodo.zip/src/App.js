import React from "react";
import AppRoute from "./Route";

function App() {
  return (
    <>
      <AppRoute />
    </>
  );
}

export default App;
