import React from 'react'
import Todoform from './Todoform'

const Reactapp=()=> {
  return (
   <>
   <Todoform/>
   </>
  )
}

export default Reactapp
