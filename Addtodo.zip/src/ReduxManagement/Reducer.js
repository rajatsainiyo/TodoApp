import { createSlice } from "@reduxjs/toolkit";

const inititalstate = {
  Todoarray: [],
  Searcharray: [],
};
const myTodo = createSlice({
  name: "Todoapp",
  initialState: inititalstate,
  reducers: {
    addtodo: (state, action) => {
      state.Todoarray = [...state.Todoarray, { ...action.payload }];
    },
    Deletetodo: (state, action) => {
      const delitem = state.Todoarray.filter((item, index) => {
        return index !== action.payload;
      });
      state.Todoarray = delitem;
    },
    Updatetodo: (state, action) => {
      //  state.Todoarray=[...action.payload]
      state.Todoarray = action.payload;
    },

    sreachitem: (state, action) => {
      state.Searcharray = [...action.payload];
    },
  },
});

export const { addtodo, Deletetodo, Updatetodo, sreachitem } = myTodo.actions;
export default myTodo.reducer;
